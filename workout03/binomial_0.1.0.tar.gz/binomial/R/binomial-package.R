#' @import ggplot2
#' @importFrom stringr str_c
#' @docType package
#' @name binomial
NULL
