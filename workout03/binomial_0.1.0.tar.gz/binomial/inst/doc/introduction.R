## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(binomial)
library(ggplot2)

## ------------------------------------------------------------------------
bin_choose(successes=5, trials=7)
bin_choose(successes=1:5, trials=7)


## ------------------------------------------------------------------------
bin_probability(successes = 2, trials = 5L, prob = 0.5)

bin_probability(successes = 0:2, trials = 5L, prob = 0.5)

## ------------------------------------------------------------------------
x <- bindis(trials = 5L, prob = 0.5)

plot(x)

## ------------------------------------------------------------------------
y <- bincum(trials = 5L, prob = 0.5)

plot(y)


